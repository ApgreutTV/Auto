# FastClicker Micro

Minimal Android root auto-clicker with coordinates and a configurable interval in **microseconds**. Intended for arm64 Android phones such as POCO X6 Pro.

## Features
- X/Y screen coordinates
- Interval from 0 to 1,000,000 microseconds
- Root-run helper creates a virtual touchscreen through Linux `/dev/uinput`
- Start/stop controls

## Important limitations
- A configured microsecond interval is a requested delay, not a guarantee of the same real tap rate. Android InputReader, the kernel, and the target app can drop or coalesce very fast touch events.
- Root alone is not sufficient: the kernel/ROM must expose `/dev/uinput` and allow it under SELinux. If it does not, the app reports an error.
- The native helper currently uses portrait panel bounds 1220×2712, which are the POCO X6 Pro's physical portrait resolution. If the device is configured differently, edit `panel_width` and `panel_height` in `fastclicker.c` and rebuild.
- This project is source code, not a prebuilt APK. The build container used to prepare it has no Android SDK/NDK or Gradle installed, so the APK could not be compiled or tested here.

## Build APK with GitHub Actions
1. Put the contents of this project at the root of a GitHub repository (the `.github/workflows/build-apk.yml` file must be at that exact path).
2. Open the repository's **Actions** tab and run **Build Android APK** (or push a change).
3. Open the successful workflow run and download the `FastClickerMicro-debug-apk` artifact. Extract `app-debug.apk` and install it on the phone.

The GitHub Actions workflow installs Java, Android SDK, NDK and CMake, then runs `gradle :app:assembleDebug`.
