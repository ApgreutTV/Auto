#define _GNU_SOURCE
#include <jni.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t keep_running = 1;
static int input_fd = -1;
static int device_created = 0;
static char pid_file_path[256];

static void handle_stop(int sig) { (void)sig; keep_running = 0; }

static int set_abs(int fd, int code, int minimum, int maximum) {
    struct uinput_abs_setup s;
    memset(&s, 0, sizeof(s));
    s.code = (uint16_t)code;
    s.absinfo.minimum = minimum;
    s.absinfo.maximum = maximum;
    s.absinfo.fuzz = 0;
    s.absinfo.flat = 0;
    return ioctl(fd, UI_ABS_SETUP, &s);
}

static int emit_event(int type, int code, int value) {
    struct input_event ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = (uint16_t)type;
    ev.code = (uint16_t)code;
    ev.value = value;
    ssize_t n = write(input_fd, &ev, sizeof(ev));
    return n == (ssize_t)sizeof(ev) ? 0 : -1;
}

static int report(void) { return emit_event(EV_SYN, SYN_REPORT, 0); }

static void cleanup(void) {
    if (input_fd >= 0 && device_created) ioctl(input_fd, UI_DEV_DESTROY);
    if (input_fd >= 0) close(input_fd);
    input_fd = -1;
    device_created = 0;
    if (pid_file_path[0]) unlink(pid_file_path);
}

static void fail(const char *message) {
    fprintf(stderr, "FASTCLICKER_ERROR: %s (errno=%d: %s)\n", message, errno, strerror(errno));
    fflush(stderr);
    cleanup();
}

static int create_virtual_touchscreen(int width, int height) {
    input_fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    if (input_fd < 0) input_fd = open("/dev/input/uinput", O_WRONLY | O_NONBLOCK);
    if (input_fd < 0) return -1;

#define SETBIT(what, code) do { if (ioctl(input_fd, (what), (code)) < 0) return -1; } while (0)
    SETBIT(UI_SET_EVBIT, EV_SYN);
    SETBIT(UI_SET_EVBIT, EV_KEY);
    SETBIT(UI_SET_EVBIT, EV_ABS);
    SETBIT(UI_SET_KEYBIT, BTN_TOUCH);
    SETBIT(UI_SET_KEYBIT, BTN_TOOL_FINGER);
    SETBIT(UI_SET_ABSBIT, ABS_X);
    SETBIT(UI_SET_ABSBIT, ABS_Y);
    SETBIT(UI_SET_ABSBIT, ABS_PRESSURE);
    SETBIT(UI_SET_ABSBIT, ABS_MT_SLOT);
    SETBIT(UI_SET_ABSBIT, ABS_MT_TRACKING_ID);
    SETBIT(UI_SET_ABSBIT, ABS_MT_POSITION_X);
    SETBIT(UI_SET_ABSBIT, ABS_MT_POSITION_Y);
    SETBIT(UI_SET_ABSBIT, ABS_MT_TOUCH_MAJOR);
#ifdef UI_SET_PROPBIT
    SETBIT(UI_SET_PROPBIT, INPUT_PROP_DIRECT);
#endif
#undef SETBIT

    if (set_abs(input_fd, ABS_X, 0, width - 1) < 0) return -1;
    if (set_abs(input_fd, ABS_Y, 0, height - 1) < 0) return -1;
    if (set_abs(input_fd, ABS_PRESSURE, 0, 255) < 0) return -1;
    if (set_abs(input_fd, ABS_MT_SLOT, 0, 9) < 0) return -1;
    if (set_abs(input_fd, ABS_MT_TRACKING_ID, 0, 65535) < 0) return -1;
    if (set_abs(input_fd, ABS_MT_POSITION_X, 0, width - 1) < 0) return -1;
    if (set_abs(input_fd, ABS_MT_POSITION_Y, 0, height - 1) < 0) return -1;
    if (set_abs(input_fd, ABS_MT_TOUCH_MAJOR, 0, 255) < 0) return -1;

    struct uinput_setup setup;
    memset(&setup, 0, sizeof(setup));
    setup.id.bustype = BUS_VIRTUAL;
    setup.id.vendor = 0x1209;
    setup.id.product = 0xFA57;
    setup.id.version = 1;
    snprintf(setup.name, UINPUT_MAX_NAME_SIZE, "FastClicker Micro Touchscreen");
    if (ioctl(input_fd, UI_DEV_SETUP, &setup) < 0) return -1;
    if (ioctl(input_fd, UI_DEV_CREATE) < 0) return -1;
    device_created = 1;
    return 0;
}

static void pause_us(int interval_us) {
    if (interval_us <= 0) return;
    struct timespec ts;
    ts.tv_sec = interval_us / 1000000;
    ts.tv_nsec = (long)(interval_us % 1000000) * 1000L;
    while (keep_running && nanosleep(&ts, &ts) < 0 && errno == EINTR) { }
}

JNIEXPORT void JNICALL
Java_com_example_fastclicker_RootDaemon_nativeRun(JNIEnv *env, jclass clazz,
                                                   jint x, jint y, jint interval_us,
                                                   jstring pid_file) {
    (void)clazz;
    keep_running = 1;
    signal(SIGTERM, handle_stop);
    signal(SIGINT, handle_stop);

    const char *pf = (*env)->GetStringUTFChars(env, pid_file, NULL);
    if (pf != NULL) {
        snprintf(pid_file_path, sizeof(pid_file_path), "%s", pf);
        (*env)->ReleaseStringUTFChars(env, pid_file, pf);
    } else {
        snprintf(pid_file_path, sizeof(pid_file_path), "/data/local/tmp/fastclicker-micro.pid");
    }

    if (x < 0 || y < 0 || interval_us < 0 || interval_us > 1000000) {
        fprintf(stderr, "FASTCLICKER_ERROR: invalid parameters\n"); fflush(stderr); cleanup(); return;
    }

    /* Device axes need an upper bound; use the POCO X6 Pro portrait panel size by default.
       The app passes screen coordinates, and the display has 1220x2712 physical pixels. */
    const int panel_width = 1220;
    const int panel_height = 2712;
    if (x >= panel_width || y >= panel_height) {
        fprintf(stderr, "FASTCLICKER_ERROR: coordinates exceed 1220x2712 panel bounds\n"); fflush(stderr); cleanup(); return;
    }

    if (create_virtual_touchscreen(panel_width, panel_height) < 0) {
        fail("cannot create virtual touchscreen; kernel may not expose /dev/uinput or root may be denied");
        return;
    }

    FILE *pfp = fopen(pid_file_path, "w");
    if (pfp) { fprintf(pfp, "%ld\n", (long)getpid()); fclose(pfp); chmod(pid_file_path, 0644); }
    printf("FASTCLICKER_RUNNING x=%d y=%d interval_us=%d; 0 means no additional pause\n", x, y, interval_us);
    fflush(stdout);

    /* Let Android InputReader discover the virtual touchscreen before sending taps. */
    struct timespec init_delay = { .tv_sec = 0, .tv_nsec = 350000000L };
    nanosleep(&init_delay, NULL);

    int tracking_id = 1;
    while (keep_running) {
        if (emit_event(EV_ABS, ABS_MT_SLOT, 0) < 0 ||
            emit_event(EV_ABS, ABS_MT_TRACKING_ID, tracking_id) < 0 ||
            emit_event(EV_ABS, ABS_MT_POSITION_X, x) < 0 ||
            emit_event(EV_ABS, ABS_MT_POSITION_Y, y) < 0 ||
            emit_event(EV_ABS, ABS_MT_TOUCH_MAJOR, 1) < 0 ||
            emit_event(EV_ABS, ABS_X, x) < 0 ||
            emit_event(EV_ABS, ABS_Y, y) < 0 ||
            emit_event(EV_ABS, ABS_PRESSURE, 80) < 0 ||
            emit_event(EV_KEY, BTN_TOUCH, 1) < 0 ||
            emit_event(EV_KEY, BTN_TOOL_FINGER, 1) < 0 || report() < 0) {
            fail("failed to write touch-down event");
            return;
        }
        if (emit_event(EV_ABS, ABS_MT_SLOT, 0) < 0 ||
            emit_event(EV_ABS, ABS_MT_TRACKING_ID, -1) < 0 ||
            emit_event(EV_ABS, ABS_MT_TOUCH_MAJOR, 0) < 0 ||
            emit_event(EV_ABS, ABS_PRESSURE, 0) < 0 ||
            emit_event(EV_KEY, BTN_TOUCH, 0) < 0 ||
            emit_event(EV_KEY, BTN_TOOL_FINGER, 0) < 0 || report() < 0) {
            fail("failed to write touch-up event");
            return;
        }
        tracking_id = tracking_id >= 60000 ? 1 : tracking_id + 1;
        pause_us(interval_us);
    }
    cleanup();
    printf("FASTCLICKER_STOPPED\n"); fflush(stdout);
}
