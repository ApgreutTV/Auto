package com.example.fastclicker;

/** Entry point launched by app_process through su, so the native helper runs as root. */
public final class RootDaemon {
    private RootDaemon() {}

    public static void main(String[] args) {
        if (args == null || args.length < 5) {
            System.err.println("Usage: RootDaemon x y intervalUs libraryPath pidFile");
            System.err.flush();
            return;
        }
        try {
            int x = Integer.parseInt(args[0]);
            int y = Integer.parseInt(args[1]);
            int intervalUs = Integer.parseInt(args[2]);
            System.load(args[3]);
            nativeRun(x, y, intervalUs, args[4]);
        } catch (Throwable t) {
            System.err.println("FASTCLICKER_ERROR: " + t);
            t.printStackTrace(System.err);
            System.err.flush();
        }
    }

    private static native void nativeRun(int x, int y, int intervalUs, String pidFile);
}
