package com.example.fastclicker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private val running = AtomicBoolean(false)
    @Volatile private var rootProcess: Process? = null

    private val pidFile = "/data/local/tmp/fastclicker-micro.pid"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF172033.toInt()
        window.navigationBarColor = 0xFF101827.toInt()
        window.decorView.setBackgroundColor(0xFFF4F6FA.toInt())

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
        }
        val scroll = ScrollView(this).apply { addView(root) }

        val title = TextView(this).apply {
            text = "FastClicker Micro"
            textSize = 26f
            setTextColor(0xFF152238.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title, matchWrap())
        root.addView(TextView(this).apply {
            text = "Root-режим · координатный тап · задержка в микросекундах"
            textSize = 14f
            setTextColor(0xFF526078.toInt())
            setPadding(0, dp(6), 0, dp(18))
        }, matchWrap())

        xInput = addNumberField(root, "X — координата по горизонтали", (resources.displayMetrics.widthPixels / 2).toString())
        yInput = addNumberField(root, "Y — координата по вертикали", (resources.displayMetrics.heightPixels / 2).toString())
        intervalInput = addNumberField(root, "Интервал между кликами (мкс)", "500")

        root.addView(TextView(this).apply {
            text = "Примеры: 1000 мкс = 1 мс (до 1000 кликов/с теоретически); 500 мкс = 0,5 мс; 100 мкс = 0,1 мс. Значение 0 — без дополнительной паузы. Реальная скорость зависит от прошивки и приложения."
            textSize = 13.5f
            setTextColor(0xFF526078.toInt())
            setPadding(0, dp(4), 0, dp(14))
        }, matchWrap())

        val coords = Button(this).apply {
            text = "Поставить точку в центр экрана"
            setOnClickListener {
                xInput.setText((resources.displayMetrics.widthPixels / 2).toString())
                yInput.setText((resources.displayMetrics.heightPixels / 2).toString())
            }
        }
        root.addView(coords, matchWrap())

        startButton = Button(this).apply {
            text = "СТАРТ (root)"
            setOnClickListener { startClicker() }
        }
        root.addView(startButton, matchWrap())

        stopButton = Button(this).apply {
            text = "СТОП"
            isEnabled = false
            setOnClickListener { stopClicker() }
        }
        root.addView(stopButton, matchWrap())

        status = TextView(this).apply {
            text = "Готово. Для работы разреши root-запрос Magisk/Superuser."
            textSize = 14f
            setTextColor(0xFF203149.toInt())
            gravity = Gravity.START
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFE5EAF2.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        })
        setContentView(scroll)
    }

    private fun addNumberField(parent: LinearLayout, label: String, initial: String): EditText {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(0xFF25354E.toInt())
            setPadding(0, dp(4), 0, dp(2))
        }, matchWrap())
        return EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 16f
            setText(initial)
            selectAllOnFocus = true
            setPadding(dp(12), dp(8), dp(12), dp(8))
            parent.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply {
                bottomMargin = dp(8)
            })
        }
    }

    private fun startClicker() {
        if (running.get()) return
        val x = xInput.text.toString().toIntOrNull()
        val y = yInput.text.toString().toIntOrNull()
        val interval = intervalInput.text.toString().toIntOrNull()
        if (x == null || y == null || interval == null) {
            showStatus("Проверь координаты и интервал: нужны целые числа.")
            return
        }
        val width = resources.displayMetrics.widthPixels
        val height = resources.displayMetrics.heightPixels
        if (x !in 0 until width || y !in 0 until height) {
            showStatus("Координаты вне экрана. Сейчас размер по метрикам приложения: ${width}×${height} px.")
            return
        }
        if (interval !in 0..1_000_000) {
            showStatus("Интервал должен быть от 0 до 1 000 000 микросекунд.")
            return
        }
        running.set(true)
        startButton.isEnabled = false
        stopButton.isEnabled = true
        showStatus("Запускаю root-процесс… Если появится запрос root, разреши его.")

        thread(name = "root-clicker-launch") {
            try {
                val apk = applicationInfo.sourceDir
                val libDir = applicationInfo.nativeLibraryDir
                val lib = "$libDir/libfastclicker.so"
                if (!File(lib).exists()) {
                    running.set(false)
                    runOnUiThread {
                        startButton.isEnabled = true
                        stopButton.isEnabled = false
                        showStatus("Не найден native-модуль. APK, возможно, собран не для arm64-v8a.")
                    }
                    return@thread
                }
                val command = "umask 022; if [ -x /system/bin/app_process64 ]; then AP=/system/bin/app_process64; else AP=/system/bin/app_process; fi; " +
                    "export CLASSPATH=${shellQuote(apk)}; export LD_LIBRARY_PATH=${shellQuote(libDir)}; " +
                    "exec \$AP /system/bin com.example.fastclicker.RootDaemon $x $y $interval ${shellQuote(lib)} ${shellQuote(pidFile)}"
                val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
                rootProcess = process
                val reader = process.inputStream.bufferedReader()
                var gotOutput = false
                while (running.get()) {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) {
                        gotOutput = true
                        runOnUiThread { showStatus(line.take(600)) }
                    }
                }
                val exit = process.waitFor()
                if (running.get()) {
                    running.set(false)
                    runOnUiThread {
                        startButton.isEnabled = true
                        stopButton.isEnabled = false
                        showStatus(if (gotOutput) "Процесс завершился (код $exit). Проверь root и поддержку /dev/uinput." else "Процесс завершился (код $exit). Проверь, выдан ли root-доступ и поддерживается ли /dev/uinput.")
                    }
                }
            } catch (t: Throwable) {
                running.set(false)
                runOnUiThread {
                    startButton.isEnabled = true
                    stopButton.isEnabled = false
                    showStatus("Ошибка запуска: ${t.message ?: t.javaClass.simpleName}")
                }
            }
        }
    }

    private fun stopClicker() {
        if (!running.getAndSet(false)) return
        showStatus("Останавливаю…")
        thread(name = "root-clicker-stop") {
            try {
                val cmd = "if [ -f ${shellQuote(pidFile)} ]; then P=\$(cat ${shellQuote(pidFile)}); kill -TERM \$P 2>/dev/null; fi; " +
                    "rm -f ${shellQuote(pidFile)}"
                ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start().waitFor()
                rootProcess?.destroy()
            } catch (_: Throwable) {
                rootProcess?.destroy()
            }
            runOnUiThread {
                startButton.isEnabled = true
                stopButton.isEnabled = false
                showStatus("Остановлено.")
            }
        }
    }

    private fun showStatus(message: String) { status.text = message }
    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun shellQuote(value: String) = "'" + value.replace("'", "'\\''") + "'"

    override fun onDestroy() {
        if (running.get()) stopClicker()
        super.onDestroy()
    }
}
